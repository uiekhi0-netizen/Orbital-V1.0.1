package com.example.orbital;

import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.*;

public class OrbitalPlugin extends JavaPlugin implements Listener, TabExecutor {

    private static final List<String> SETTING_KEYS = List.of(
            "nuke.ring-gap", "nuke.dot-gap", "nuke.height", "nuke.fuse", "nuke.gravity",
            "stab.top-y", "stab.bottom-y", "stab.gap", "stab.fuse", "stab.at-player",
            "limits.max-ring", "limits.max-amount", "limits.max-tnt");
    private static final Set<String> BOOL_KEYS = Set.of("nuke.gravity", "stab.at-player");
    private static final Set<String> DOUBLE_KEYS = Set.of("nuke.ring-gap", "nuke.dot-gap", "nuke.height", "stab.gap");

    private NamespacedKey keyType;
    private NamespacedKey keyRing;
    private NamespacedKey keyConsume;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        keyType = new NamespacedKey(this, "orbital_type");
        keyRing = new NamespacedKey(this, "orbital_ring");
        keyConsume = new NamespacedKey(this, "orbital_consume");
        getServer().getPluginManager().registerEvents(this, this);
        PluginCommand cmd = getCommand("orbital");
        if (cmd != null) {
            cmd.setExecutor(this);
            cmd.setTabCompleter(this);
        }
    }

    // =====================================================================
    //  COMMANDS
    // =====================================================================
    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (!s.hasPermission("orbital.admin")) {
            s.sendMessage("§cคุณไม่มีสิทธิ์ใช้คำสั่งนี้");
            return true;
        }
        if (a.length == 0) {
            help(s);
            return true;
        }
        switch (a[0].toLowerCase()) {
            case "give" -> cmdGive(s, a);
            case "settings" -> cmdSettings(s, a);
            case "line" -> cmdLine(s, a);
            case "strike" -> cmdStrike(s, a);
            default -> help(s);
        }
        return true;
    }

    private void help(CommandSender s) {
        s.sendMessage("§6/orbital give <@s|@a|@p|@r|ชื่อ> nuke <ring> [จำนวน]");
        s.sendMessage("§6/orbital give <ผู้เล่น> stab [จำนวน]");
        s.sendMessage("§6/orbital line <nuke|stab> [ring]  §7(ถือเบ็ดธรรมดา ใช้ได้ครั้งเดียว)");
        s.sendMessage("§6/orbital strike <x y z | x,y,z> <nuke|stab> [ring]");
        s.sendMessage("§6/orbital settings [key] [value]");
    }

    // ---------- give ----------
    private void cmdGive(CommandSender s, String[] a) {
        if (a.length < 3) {
            help(s);
            return;
        }
        List<Player> targets = selectPlayers(s, a[1]);
        if (targets == null) return;
        if (targets.isEmpty()) {
            s.sendMessage("§cไม่พบผู้เล่น");
            return;
        }

        String type = a[2].toLowerCase();
        int ring = 0;
        int amount = 1;
        try {
            if (type.equals("nuke")) {
                if (a.length < 4) {
                    s.sendMessage("§cใส่จำนวนวง: /orbital give <ผู้เล่น> nuke <ring> [จำนวน]");
                    return;
                }
                ring = Integer.parseInt(a[3]);
                if (a.length >= 5) amount = Integer.parseInt(a[4]);
            } else if (type.equals("stab")) {
                if (a.length >= 4) amount = Integer.parseInt(a[3]);
            } else {
                s.sendMessage("§ctype ต้องเป็น nuke หรือ stab");
                return;
            }
        } catch (NumberFormatException ex) {
            s.sendMessage("§cต้องใส่ตัวเลขเท่านั้น");
            return;
        }

        int maxRing = getConfig().getInt("limits.max-ring", 30);
        int maxAmount = getConfig().getInt("limits.max-amount", 64);
        if (type.equals("nuke") && (ring < 1 || ring > maxRing)) {
            s.sendMessage("§cring ต้องอยู่ระหว่าง 1-" + maxRing);
            return;
        }
        if (amount < 1 || amount > maxAmount) {
            s.sendMessage("§cจำนวนต้องอยู่ระหว่าง 1-" + maxAmount);
            return;
        }

        for (Player t : targets) {
            for (int i = 0; i < amount; i++) {
                Map<Integer, ItemStack> left = t.getInventory().addItem(createRod(type, ring));
                for (ItemStack st : left.values()) {
                    t.getWorld().dropItemNaturally(t.getLocation(), st);
                }
            }
        }
        s.sendMessage("§aให้ Orbital " + type + (ring > 0 ? " ring=" + ring : "")
                + " x" + amount + " กับ " + targets.size() + " คน");
    }

    private List<Player> selectPlayers(CommandSender s, String sel) {
        List<Player> out = new ArrayList<>();
        if (sel.startsWith("@")) {
            try {
                for (Entity e : Bukkit.selectEntities(s, sel)) {
                    if (e instanceof Player p) out.add(p);
                }
            } catch (IllegalArgumentException ex) {
                s.sendMessage("§cตัวเลือกผู้เล่นไม่ถูกต้อง: " + sel);
                return null;
            }
        } else {
            Player p = Bukkit.getPlayerExact(sel);
            if (p != null) out.add(p);
        }
        return out;
    }

    // ---------- line (ผูกกับเบ็ดธรรมดา) ----------
    private void cmdLine(CommandSender s, String[] a) {
        if (!(s instanceof Player p)) {
            s.sendMessage("§cใช้ได้เฉพาะผู้เล่นในเกม");
            return;
        }
        if (a.length < 2) {
            help(s);
            return;
        }
        ItemStack hand = p.getInventory().getItemInMainHand();
        if (hand.getType() != Material.FISHING_ROD) {
            s.sendMessage("§cต้องถือเบ็ดไว้ในมือหลัก");
            return;
        }

        String type = a[1].toLowerCase();
        int ring = 0;
        if (type.equals("nuke")) {
            if (a.length < 3) {
                s.sendMessage("§cใส่จำนวนวง: /orbital line nuke <ring>");
                return;
            }
            try {
                ring = Integer.parseInt(a[2]);
            } catch (NumberFormatException ex) {
                s.sendMessage("§cring ต้องเป็นตัวเลข");
                return;
            }
            int maxRing = getConfig().getInt("limits.max-ring", 30);
            if (ring < 1 || ring > maxRing) {
                s.sendMessage("§cring ต้องอยู่ระหว่าง 1-" + maxRing);
                return;
            }
        } else if (!type.equals("stab")) {
            s.sendMessage("§ctype ต้องเป็น nuke หรือ stab");
            return;
        }

        ItemMeta meta = hand.getItemMeta();
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        pdc.set(keyType, PersistentDataType.STRING, type);
        pdc.set(keyRing, PersistentDataType.INTEGER, ring);
        pdc.set(keyConsume, PersistentDataType.BYTE, (byte) 0); // ไม่แตก
        meta.setLore(List.of("§7Linked: §f" + type + (ring > 0 ? " ring " + ring : ""),
                "§7คลิกขวาได้ 1 ครั้ง แล้วต้องลิงก์ใหม่"));
        hand.setItemMeta(meta);
        p.getInventory().setItemInMainHand(hand);
        s.sendMessage("§aลิงก์เบ็ดกับ " + type + (ring > 0 ? " ring " + ring : "") + " แล้ว (ใช้ได้ 1 ครั้ง)");
    }

    // ---------- strike ----------
    // /orbital strike <x> <y> <z> <nuke|stab> [ring]   หรือ   /orbital strike x,y,z <nuke|stab> [ring]
    private void cmdStrike(CommandSender s, String[] a) {
        if (a.length < 3) {
            help(s);
            return;
        }
        String[] c;
        int next;
        if (a[1].contains(",")) {
            c = a[1].split(",");
            if (c.length != 3) {
                s.sendMessage("§cพิกัดต้องเป็นรูปแบบ x,y,z");
                return;
            }
            next = 2;
        } else {
            if (a.length < 5) {
                help(s);
                return;
            }
            c = new String[]{a[1], a[2], a[3]};
            next = 4;
        }

        Location base = originOf(s);
        double x, y, z;
        try {
            x = coord(c[0].trim(), base.getX());
            y = coord(c[1].trim(), base.getY());
            z = coord(c[2].trim(), base.getZ());
        } catch (NumberFormatException ex) {
            s.sendMessage("§cพิกัดไม่ถูกต้อง (ใช้ตัวเลข หรือ ~ ได้)");
            return;
        }

        if (a.length <= next) {
            help(s);
            return;
        }
        String type = a[next].toLowerCase();
        int ring = 0;
        if (type.equals("nuke")) {
            if (a.length <= next + 1) {
                s.sendMessage("§cใส่จำนวนวงด้วย");
                return;
            }
            try {
                ring = Integer.parseInt(a[next + 1]);
            } catch (NumberFormatException ex) {
                s.sendMessage("§cring ต้องเป็นตัวเลข");
                return;
            }
            int maxRing = getConfig().getInt("limits.max-ring", 30);
            if (ring < 1 || ring > maxRing) {
                s.sendMessage("§cring ต้องอยู่ระหว่าง 1-" + maxRing);
                return;
            }
        } else if (!type.equals("stab")) {
            s.sendMessage("§ctype ต้องเป็น nuke หรือ stab");
            return;
        }

        Location loc = new Location(base.getWorld(), x, y, z);
        Player owner = (s instanceof Player p) ? p : null;
        fire(owner, type, ring, loc);
        s.sendMessage("§aยิง " + type + (ring > 0 ? " ring " + ring : "")
                + String.format(" ที่ %.1f, %.1f, %.1f", x, y, z));
    }

    private Location originOf(CommandSender s) {
        if (s instanceof Player p) return p.getLocation();
        if (s instanceof BlockCommandSender b) return b.getBlock().getLocation().add(0.5, 0, 0.5);
        return Bukkit.getWorlds().get(0).getSpawnLocation();
    }

    private double coord(String t, double base) {
        if (t.startsWith("~")) {
            String rest = t.substring(1);
            return base + (rest.isEmpty() ? 0 : Double.parseDouble(rest));
        }
        return Double.parseDouble(t);
    }

    // ---------- settings ----------
    private void cmdSettings(CommandSender s, String[] a) {
        FileConfiguration cfg = getConfig();
        if (a.length == 1) {
            s.sendMessage("§6--- Orbital settings ---");
            for (String k : SETTING_KEYS) s.sendMessage("§e" + k + " §7= §f" + cfg.get(k));
            return;
        }
        String key = a[1].toLowerCase();
        if (!SETTING_KEYS.contains(key)) {
            s.sendMessage("§cไม่มี key นี้ ลอง /orbital settings เพื่อดูทั้งหมด");
            return;
        }
        if (a.length == 2) {
            s.sendMessage("§e" + key + " §7= §f" + cfg.get(key));
            return;
        }
        try {
            Object v;
            if (BOOL_KEYS.contains(key)) {
                if (!a[2].equalsIgnoreCase("true") && !a[2].equalsIgnoreCase("false")) {
                    s.sendMessage("§cค่าต้องเป็น true หรือ false");
                    return;
                }
                v = Boolean.parseBoolean(a[2]);
            } else if (DOUBLE_KEYS.contains(key)) {
                v = Double.parseDouble(a[2]);
            } else {
                v = Integer.parseInt(a[2]);
            }
            cfg.set(key, v);
            saveConfig();
            s.sendMessage("§aตั้ง " + key + " = " + v);
        } catch (NumberFormatException ex) {
            s.sendMessage("§cค่าต้องเป็นตัวเลข");
        }
    }

    // =====================================================================
    //  ITEM + EVENTS
    // =====================================================================
    private ItemStack createRod(String type, int ring) {
        ItemStack item = new ItemStack(Material.FISHING_ROD);
        ItemMeta meta = item.getItemMeta();
        if (type.equals("nuke")) {
            meta.setDisplayName("§c§lOrbital Nuke Shot §7(ring " + ring + ")");
        } else {
            meta.setDisplayName("§b§lOrbital Stab Shot");
        }
        meta.setLore(List.of("§7คลิกขวาเพื่อยิง", "§7ใช้ครั้งเดียวแล้วแตก"));
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        pdc.set(keyType, PersistentDataType.STRING, type);
        pdc.set(keyRing, PersistentDataType.INTEGER, ring);
        pdc.set(keyConsume, PersistentDataType.BYTE, (byte) 1); // แตกหลังใช้
        item.setItemMeta(meta);
        return item;
    }

    private boolean isOrbital(ItemStack item) {
        return item != null && item.getType() == Material.FISHING_ROD && item.hasItemMeta()
                && item.getItemMeta().getPersistentDataContainer().has(keyType, PersistentDataType.STRING);
    }

    @EventHandler
    public void onFish(PlayerFishEvent e) {
        if (isOrbital(e.getPlayer().getInventory().getItemInMainHand())) e.setCancelled(true);
    }

    @EventHandler
    public void onUse(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        Player p = e.getPlayer();
        ItemStack hand = p.getInventory().getItemInMainHand();
        if (!isOrbital(hand)) return;

        e.setCancelled(true); // ไม่ให้เหวี่ยงเบ็ดจริง
        if (!p.hasPermission("orbital.use")) return;

        ItemMeta meta = hand.getItemMeta();
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        String type = pdc.get(keyType, PersistentDataType.STRING);
        int ring = pdc.getOrDefault(keyRing, PersistentDataType.INTEGER, 1);
        boolean consume = pdc.getOrDefault(keyConsume, PersistentDataType.BYTE, (byte) 1) == 1;

        Location center;
        if (type.equals("stab") && getConfig().getBoolean("stab.at-player", false)) {
            center = p.getLocation();
        } else {
            RayTraceResult r = p.getWorld().rayTraceBlocks(
                    p.getEyeLocation(), p.getEyeLocation().getDirection(), 200,
                    FluidCollisionMode.NEVER, true);
            if (r == null) {
                p.sendMessage("§cไม่พบจุดที่เล็ง (ไกลเกิน 200 บล็อก)");
                return;
            }
            center = r.getHitPosition().toLocation(p.getWorld());
        }

        if (consume) {
            // เบ็ดแตก
            if (hand.getAmount() <= 1) {
                p.getInventory().setItemInMainHand(null);
            } else {
                hand.setAmount(hand.getAmount() - 1);
                p.getInventory().setItemInMainHand(hand);
            }
            p.playSound(p.getLocation(), Sound.ENTITY_ITEM_BREAK, 1f, 1f);
        } else {
            // เบ็ดลิงก์: ไม่แตก แต่ล้างลิงก์ ต้องลิงก์ใหม่
            pdc.remove(keyType);
            pdc.remove(keyRing);
            pdc.remove(keyConsume);
            meta.setLore(null);
            hand.setItemMeta(meta);
            p.getInventory().setItemInMainHand(hand);
            p.sendMessage("§7ลิงก์หมดแล้ว ใช้ /orbital line เพื่อลิงก์ใหม่");
        }

        fire(p, type, ring, center);
    }

    // =====================================================================
    //  STRIKES
    // =====================================================================
    private void fire(Player owner, String type, int ring, Location center) {
        if (type.equals("nuke")) strikeNuke(owner, center, ring);
        else strikeStab(owner, center);
    }

    /** เสก TNT ทุกวงพร้อมกัน เป็นวงกลมซ้อนกันบนระนาบเดียว */
    private void strikeNuke(Player owner, Location center, int rings) {
        FileConfiguration cfg = getConfig();
        double ringGap = Math.max(0.5, cfg.getDouble("nuke.ring-gap", 3.0));
        double dotGap = Math.max(0.5, cfg.getDouble("nuke.dot-gap", 2.0));
        double height = cfg.getDouble("nuke.height", 20.0);
        int fuse = Math.max(1, cfg.getInt("nuke.fuse", 40));
        boolean gravity = cfg.getBoolean("nuke.gravity", true);
        int maxTnt = cfg.getInt("limits.max-tnt", 5000);

        World w = center.getWorld();
        double y = Math.min(center.getY() + height, w.getMaxHeight() - 1);
        int spawned = 0;

        spawnTnt(owner, new Location(w, center.getX(), y, center.getZ()), fuse, gravity);
        spawned++;

        for (int r = 1; r <= rings; r++) {
            double radius = r * ringGap;
            int count = Math.max(6, (int) Math.round(2 * Math.PI * radius / dotGap));
            double twist = (r % 2) * Math.PI / count; // สลับตำแหน่งให้ดูสวย
            for (int i = 0; i < count; i++) {
                if (spawned >= maxTnt) return;
                double ang = 2 * Math.PI * i / count + twist;
                Location loc = new Location(w,
                        center.getX() + Math.cos(ang) * radius, y,
                        center.getZ() + Math.sin(ang) * radius);
                spawnTnt(owner, loc, fuse, gravity);
                spawned++;
            }
        }
    }

    /** เสา TNT ตั้งแต่ top-y ถึง bottom-y ระเบิดทันที */
    private void strikeStab(Player owner, Location center) {
        FileConfiguration cfg = getConfig();
        World w = center.getWorld();
        int top = Math.min(cfg.getInt("stab.top-y", 100), w.getMaxHeight() - 1);
        int bottom = Math.max(cfg.getInt("stab.bottom-y", -59), w.getMinHeight());
        if (top < bottom) {
            int t = top;
            top = bottom;
            bottom = t;
        }
        double gap = Math.max(0.5, cfg.getDouble("stab.gap", 2.0));
        int fuse = Math.max(1, cfg.getInt("stab.fuse", 1));
        int maxTnt = cfg.getInt("limits.max-tnt", 5000);

        int spawned = 0;
        for (double y = top; y >= bottom && spawned < maxTnt; y -= gap) {
            spawnTnt(owner, new Location(w, center.getX(), y, center.getZ()), fuse, false);
            spawned++;
        }
    }

    private void spawnTnt(Player owner, Location loc, int fuse, boolean gravity) {
        loc.getWorld().spawn(loc, TNTPrimed.class, tnt -> {
            tnt.setFuseTicks(fuse);
            tnt.setGravity(gravity);
            tnt.setVelocity(new Vector(0, 0, 0));
            if (owner != null) tnt.setSource(owner);
        });
    }

    // =====================================================================
    //  TAB COMPLETE
    // =====================================================================
    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        List<String> out = new ArrayList<>();
        if (!s.hasPermission("orbital.admin")) return out;

        if (a.length == 1) {
            out.addAll(List.of("give", "settings", "line", "strike"));
        } else {
            switch (a[0].toLowerCase()) {
                case "give" -> {
                    if (a.length == 2) {
                        out.addAll(List.of("@s", "@a", "@p", "@r"));
                        Bukkit.getOnlinePlayers().forEach(p -> out.add(p.getName()));
                    } else if (a.length == 3) {
                        out.addAll(List.of("nuke", "stab"));
                    } else if (a.length == 4 && a[2].equalsIgnoreCase("nuke")) {
                        out.addAll(List.of("1", "5", "10", "20"));
                    }
                }
                case "line" -> {
                    if (a.length == 2) out.addAll(List.of("nuke", "stab"));
                    else if (a.length == 3 && a[1].equalsIgnoreCase("nuke")) out.addAll(List.of("1", "5", "10", "20"));
                }
                case "strike" -> {
                    boolean comma = a.length > 1 && a[1].contains(",");
                    int typeIdx = comma ? 2 : 4;
                    if (a.length <= 4 && !comma) out.add("~");
                    else if (a.length == 2) out.add("~,~,~");
                    else if (a.length == typeIdx + 1) out.addAll(List.of("nuke", "stab"));
                    else if (a.length == typeIdx + 2 && a[typeIdx].equalsIgnoreCase("nuke"))
                        out.addAll(List.of("5", "10", "20"));
                }
                case "settings" -> {
                    if (a.length == 2) out.addAll(SETTING_KEYS);
                    else if (a.length == 3 && BOOL_KEYS.contains(a[1].toLowerCase())) out.addAll(List.of("true", "false"));
                }
                default -> { }
            }
        }
        String last = a[a.length - 1].toLowerCase();
        out.removeIf(x -> !x.toLowerCase().startsWith(last));
        return out;
    }
}
